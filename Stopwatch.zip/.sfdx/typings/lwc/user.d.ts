/**
 * User's Id.
 */
declare module "@salesforce/user/Id" {
    const id: string;
    export default id;
}
